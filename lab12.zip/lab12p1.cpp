//Noah Johnson
//CSCE 1040.302

#include <iostream>

using namespace std;
class Employee {
	protected:	double sal;
	public:		Employee(double s) : sal{s} {}
			virtual double Payment() { return sal; }
			void prt() {
				cout << "Salary=" << Payment() << endl; }
}; //class Employee

class Manager : public Employee {
	double inc;
	public:	Manager(double s, double i) : Employee(s), inc{i} {}
		double Payment() { return sal*inc; }
}; //class Manager

int main() {
	Employee e1(1500);
	Manager m1(1500, 1.5);
	cout << "Exercise about inheritance and polymorphism" << endl;
	e1.prt();
	m1.prt();
} //int main()
