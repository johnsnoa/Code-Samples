//Noah Johnson

#include <iostream>
#include <stdio.h>
#include <string.h>

using namespace std;
class Employee {
	char name[20];
	public:	Employee(char* n) {
			strcpy(name, n);
		} //Full constructor
		virtual void show_info() {
			cout << "Employee" << endl;
		} //v void show_info()
		char *Name() { return name; }
}; //class Employee

class Manager : public Employee {
	public: Manager(char* n) : Employee(n) {}
		void show_info() {
			cout << Name() << endl;
		} //void show_info()
}; //class Manager : public Employee

class Worker : public Employee { 
	public: Worker(char* n) : Employee(n) {}
		void show_info() {
			cout << Name() << endl;
		} //void show_info()
}; //class Worker : public Employee

class Officer : public Employee {
	public: Officer(char* n) : Employee(n) {}
		void show_info() {
			cout << Name() << endl;
		} //void show_info()
}; //class Officer : public Employee

class Technician : public Employee {
	public: Technician(char* n) : Employee(n) {}
		void show_info() {
			cout << Name() << endl;
		} //void show_info()
}; //class Officer : public Employee

int main() {
	Employee Rafa("Rafa"); 
	Manager Mario("Mario"); 
	Worker Anton("Anton"); 
	Officer Luis("Luis"); 
	Technician Pablo("Pablo");
	
	Employee *pe; 
	
	cout << "\nInheritance and Polymorphism:\n" << endl;
	pe = &Rafa;  pe->show_info(); 
	pe = &Mario; pe-> show_info(); 
	pe = &Anton; pe-> show_info(); 
	pe = &Luis;  pe-> show_info(); 
	pe = &Pablo; pe-> show_info();
	cout << "Ya he terminado." << endl;
}
