//Noah Johnson
#define NUM_EMPLOYEES 6

#include <iostream>
#include <stdio.h>
#include <string.h>

using namespace std;
class Employee {
	char name[20];
	long salary;
	public:	Employee(char* n, long s) : salary{s} {
			strcpy(name, n);
		} //Full constructor
		virtual void show_info() {
			cout << name << " " << salary << endl;
		} //v void show_info()
		char *Name() { return name; }
		long Salary() { return salary; }
}; //class Employee

class Manager : public Employee {
	protected char* degree;
	public: Manager(char* n, long s, char* d) : Employee(n, s) { strcpy(degree, d); }
		void show_info() {
			cout << Name() << " " << Salary() << " " << degree << endl;
		} //void show_info()
}; //class Manager : public Employee

class Worker : public Employee { 
	protected char* position;
	public: Worker(char* n, long s, char* p) : Employee(n, s) { strcpy(position, p); }
		void show_info() {
			cout << Name() << " " << Salary() << " " << position << endl;
		} //void show_info()
}; //class Worker : public Employee

class Officer : public Employee {
	public: Officer(char* n, long s) : Employee(n, s) {}
		void show_info() {
			cout << Name() << " " << Salary() << endl;
		} //void show_info()
}; //class Officer : public Employee

class Technician : public Employee {
	public: Technician(char* n, long s) : Employee(n, s) {}
		void show_info() {
			cout << Name() << " " << Salary() << endl;
		} //void show_info()
}; //class Officer : public Employee

int main() {
	Employee* EmployeeList[NUM_EMPLOYEES]; 
	EmployeeList[0] = new Manager("Carla Garcia", (long) 35000, "Economist"); 
	EmployeeList[1] = new Manager ("Juan Perez", (long) 38000, "Engineer"); 
	EmployeeList[2] = new Officer("Pedro Egia", (long) 18000, " Officer 1"); 
	EmployeeList[3] = new Officer ("Luisa Penia", (long) 15000, " Officer 2"); 
	EmployeeList[4] = new Technician("Javier Ramos", (long) 19500, "Welder"); 
	EmployeeList[5] = new Technician ("Amaia Bilbao", (long) 12000, "Electricist"); 
	for(int i=0;i<NUM_EMPLOYEES;i++)
		EmployeeList[i]->show_info();
} //int main()
